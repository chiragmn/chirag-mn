from .models import students
from django.contrib import admin

admin.site.register(students)